﻿using UnityEngine;
using System;
using System.Collections.Generic;

[Serializable]
public class ActorContainer {
	public List<ActorData> actors = new List<ActorData>();
}
