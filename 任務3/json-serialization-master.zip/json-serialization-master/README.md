# json-serialization
A tutorial on how to serialize objects in Unity using JSON
